
import tensorflow as tf


db = {
    'host': '192.168.123.228',
    'username': 'db_user',
    'password': 'db_password',
    'database': 'db_name',
    'table': 'dbo.table_name'
}