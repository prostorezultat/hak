# Двигайся не стой жизнь бежит и ты за ней

import string
import tensorflow as tf
import numpy as np
import pandas as pd
import docx
import os

# уже было

# import

global tuberkulez
tuberkulez='смэрть'
paths = []
folder = "C:/dataset/датакек/DataSet_Razmetra/Алтайский край/3_1"
for root, dirs, files in os.walk(folder):
    for file in files:
        if file.endswith('docx') and not file.startswith('~'):
            paths.append(os.path.join(root, file))
i = 0
doc = [0]

# невообразимопотрясающий массив
# super_massiv = []
# for k in range(77):
#     a2 = []
#     for j in range(12):
#         a3 = []
#         for i in range(12):
#             a3.append(0)
#         a2.append(a3)
#     super_massiv.append(a3)

global massivchik
massivchik = []
for j in range(3):
    a2 = []
    for i in range(13):
        a2.append(0)
    massivchik.append(a2)
massivchik[2][5] = 'Колонка на кайфе'

i = 0
for path in paths:

    if os.path.basename(path) == 'Expertise_Text.docx':
        doc = docx.Document(path)

        properties = doc.core_properties
        print('Автор документа:', properties.author)

        # print('Автор последней правки:', properties.last_modified_by)
        # print('Дата создания документа:', properties.created)
        # print('Дата последней правки:', properties.modified)
        # print('Дата последней печати:', properties.last_printed)
        # print('Количество сохранений:', properties.revision)

        local_folder = os.path.abspath(path)
        local_folder = local_folder[0:-20]

        # кекаем
        i = i + 1
        print(local_folder, ' kek №', i)

        local_methods = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]

        text = []
        par_counter = 0
        corruption_count = 0

        for paragraph in doc.paragraphs:
            string = paragraph.text
            cursor = 1
            par_counter = par_counter + 1
            print('абзац номер ', par_counter)
            text.append(paragraph.text)

            while string.find('подпункт', cursor) > 0:
                cursor = string.find('подпункт', cursor)
                cursor2 = 0
                cursor3 = 0
                if string.find('«', cursor, cursor + 12) > 0:
                    print('\nтут коррупция!!!\n')

                    print(string[cursor:cursor + 30])


                    corruption_count = corruption_count + 1
                    cursor2 = string.find('«', cursor)
                    cursor2 = cursor2 + 1
                    cursor3 = cursor2 + 10
                    print('курсор2 ', cursor2, string[cursor2], 'курсор3 ', cursor3, string[cursor3])
                    massivchik[i - 1][12] = massivchik[i - 1][12],string[cursor2],string[cursor3]

                    if string[cursor3] == 3 and string[cursor2] == 'а':
                        massivchik[i - 1][0] = '1'
                        print(string[cursor2])
                    #
                    # if cursor3 == 3 and cursor2 == 'б':
                    #     massivchik[i - 1][1] = 'true'
                    # if cursor3 == 3 and cursor2 == 'в':
                    #     massivchik[i - 1][2] = 'true'
                    # if cursor3 == 3 and cursor2 == 'г':
                    #     massivchik[i - 1][3] = 'true'
                    # if cursor3 == 3 and cursor2 == 'д':
                    #     massivchik[i - 1][4] = 'true'
                    # if cursor3 == 3 and cursor2 == "е":
                    #     massivchik[i - 1][5] = 'true'
                    # if string[cursor3] == 3 and string[cursor2] == "ж":
                    #     massivchik[i - 1][6] = "true"
                    # if cursor3 == 3 and cursor2 == "з":
                    #     massivchik[i - 1][7] = 'true'
                    # if cursor3 == 3 and cursor2 == "и":
                    #     massivchik[i - 1][8] = 'true'
                    # if cursor3 == 4 and cursor2 == "а":
                    #     massivchik[i - 1][9] = 'true'
                    # if cursor3 == 4 and cursor2 == "б":
                    #     massivchik[i - 1][10] = 'true'
                    # if cursor3 == 4 and cursor2 == 'в':
                    #     massivchik[i - 1][11] = 'true'

                cursor = string.find('подпункт', cursor)
                # print(string[cursor:cursor + 10])
                cursor = cursor + 9

        print('скока тут карупцеи ', corruption_count)
        print(i)
        local_methods[3] = "бугага"
        print(local_methods[3])
        print(local_methods)
        print(massivchik)
    # print('\n'.join(text))

    # if os.path.basename(path) == 'Expertise_Text.docx':
    #     properties.method[12]
    #
    # properties.method[0] = 1

# for doc in docs:
#     if os.path.split(path)[1] == 'Edition_Text.docx':
#         for doc


# print(doc[0])
# for paragraph in doc.paragraphs:
#     paragraph.text == paragraph.text("5.3")
