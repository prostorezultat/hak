import zipfile, re, os, shutil
from array import *
from tkinter import *
from tkinter import filedialog
from tkinter import scrolledtext
import tkinter.scrolledtext as ScrolledText
mystr = ''
class color:
   PURPLE = '\033[95m'
   CYAN = '\033[96m'
   DARKCYAN = '\033[36m'
   BLUE = '\033[94m'
   GREEN = '\033[92m'
   YELLOW = '\033[93m'
   RED = '\033[91m'
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'

def clck():

    i = 1
    biba = 0
    words = ['gog','Hello', 'ttt']
    whatword = []
    mystr = ''

    path, dirs, files = next(os.walk("cor_test"))
    file_count = len(files)

    while i < file_count + 1:

        docx = zipfile.ZipFile('cor_test/test'+ str(i) +'.docx')
        content = docx.read('word/document.xml').decode('utf-8')
        cleaned = re.sub('<(.|\n)*?>','',content)
        if set(words) & set(cleaned.split()):
            biba = 0
            while biba < len(words):
                if words[biba] in cleaned:
                    whatword.append(words[biba])
                biba = biba + 1
                if len(whatword) > 0:
                    esbo = 0
                    while esbo <= len(whatword):
                        mystr = mystr + '\nВ документе есть слова из списка: ' + whatword[esbo]
                        print('В строке есть слова из списка: ' + whatword[esbo])
                        whatword = []
                        esbo = esbo + 1
        else:
            mystr = mystr + '\nВ документе №' + str(i) + ' слов из словаря не обнаружено'
            print('В документе №' + str(i) + ' слов из словаря не обнаружено')
        mystr = mystr + cleaned + '\n'
        if i - 2 == len(words):
            master = Tk()

            st = ScrolledText.ScrolledText(master)
            st.pack()

            st.insert(INSERT, mystr)

            print( st.get(1.0, END) )
        print(cleaned)
        i += 1

#Интерфейс#


def opfile():
    file = filedialog.askopenfilename(filetypes = (("Microsoft Document","*.docx"),("all files","*.*")))
    shutil.move(file,"./cor_test/")

window = Tk()
window.title("Анализатор коррупции")
lbl = Label(window, text="Привет", font=("Script", 50))
lbl.grid(column=0, row=0)

btn_start = Button(window, text="Старт", command=clck)
btn_open = Button(window, text="Загрузка файлов", command=opfile)

btn_start.grid(column=1, row=0)
btn_open.grid(column=2, row=0)

window.geometry('400x250')

window.mainloop()